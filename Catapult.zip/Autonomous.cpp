/*#include "WPILib.h"

class Autonomous
{
public:
	Autonomous
};*/
