#include "Catapult.h"

const float MIN_FIRING_TIME_IN_SECONDS = 1.0;

Catapult::Catapult(Controllers* driverInput, int catapaultPWM, int leftLimitSwitch, int rightLimitSwitch) 
{
	this->driverInput = driverInput;
	ChooChooMotor = new Victor(2);
	LeftLimitSwitch = new DigitalIOButton(leftLimitSwitch);
	RightLimitSwitch = new DigitalIOButton(rightLimitSwitch);
	catapultState = CATAPULT_STATE_ARM;
	MaxChooChooMotorSpeed = 0.8;
	timer = new Timer();
	timer->Reset();
}

void Catapult::SetSafeToFire(bool safeFire)
{
	SafeToFire = safeFire;
}

void Catapult::GetInputs()
{
	CommandToFire = driverInput->IsFireButtonPressed();
	//CatapultArmed = (!LeftLimitSwitch->Get() || !RightLimitSwitch->Get() || driverInput->IsDebugArmButtonPressed());
	CatapultArmed = (!RightLimitSwitch->Get() || driverInput->IsDebugArmButtonPressed());
	SmartDashboard::PutBoolean("rightbutton", RightLimitSwitch->Get());
	//CatapultArmed = (false);
}
void Catapult::ExecStep(void)
{
	//ChooChooMotorSpeed = MaxChooChooMotorSpeed;
	switch (catapultState)
	{
		case CATAPULT_STATE_ARM:
			if (CatapultArmed)
			{
				ChooChooMotorSpeed = 0.0;
				catapultState = CATAPULT_STATE_ARMED;
			}
			else
			{
				ChooChooMotorSpeed = MaxChooChooMotorSpeed;
			}
			break;
			
		case CATAPULT_STATE_ARMED:
			ChooChooMotorSpeed = 0.0;
			if (CommandToFire)
			{
				catapultState = CATAPULT_STATE_FIRE;
			}
			break;
			
		case CATAPULT_STATE_FIRE:
			if (SafeToFire)
			{
				ChooChooMotorSpeed = MaxChooChooMotorSpeed;
				catapultState = CATAPULT_STATE_FIRING;
				timer->Reset();
				timer->Start();
			}
			if (!CatapultArmed)
			{
				ChooChooMotorSpeed = 0.0;
				catapultState = CATAPULT_STATE_ARM;
			}
			break;
		case CATAPULT_STATE_FIRING:
			if (timer->Get() >= MIN_FIRING_TIME_IN_SECONDS)
			{
				catapultState = CATAPULT_STATE_ARM;
			}
			ChooChooMotorSpeed = MaxChooChooMotorSpeed;
			break;
	}
}
	void Catapult::SetOutputs()
	{
			ChooChooMotor->Set(ChooChooMotorSpeed);
			//ChooChooMotor->Set(1.0);
	}


